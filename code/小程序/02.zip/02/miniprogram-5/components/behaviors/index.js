
export default Behavior({
  data: {
    msg:'behaviors内的数据'
  },
})
